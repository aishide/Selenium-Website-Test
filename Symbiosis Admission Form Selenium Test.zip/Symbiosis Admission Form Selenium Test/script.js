function validateForm(){

let name = document.getElementById("name").value.trim();
let email = document.getElementById("email").value.trim();
let password = document.getElementById("password").value;
let confirmPassword = document.getElementById("confirmPassword").value;
let male = document.getElementById("male").checked;
let female = document.getElementById("female").checked;
let course = document.getElementById("course").value;


// NAME VALIDATION
let namePattern = /^[A-Za-z\s]+$/;

if(name === ""){
alert("Name cannot be empty");
return false;
}

if(!name.match(namePattern)){
alert("Name should contain only letters (no numbers allowed)");
return false;
}


// EMAIL VALIDATION
let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

if(!email.match(emailPattern)){
alert("Please enter a valid Email ID");
return false;
}


// PASSWORD VALIDATION
// At least 8 characters, 1 uppercase, 1 lowercase, 1 number

let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

if(!password.match(passwordPattern)){
alert("Password must contain:\n• At least 8 characters\n• One uppercase letter\n• One lowercase letter\n• One number");
return false;
}


// CONFIRM PASSWORD
if(password !== confirmPassword){
alert("Passwords do not match");
return false;
}


// GENDER VALIDATION
if(!male && !female){
alert("Please select gender");
return false;
}


// COURSE VALIDATION
if(course === ""){
alert("Please select a course");
return false;
}


alert("Registration Successful!");

return true;

}