from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file:///C:/Users/HP/OneDrive/Desktop/Symbiosis Admission Form Selenium Test/index.html")

time.sleep(2)


def test_valid_registration():
    driver.find_element(By.ID,"name").send_keys("Aishi")

    driver.find_element(By.ID,"email").send_keys("aishi@gmail.com")

    driver.find_element(By.ID,"password").send_keys("Secure123")

    driver.find_element(By.ID,"confirmPassword").send_keys("Secure123")

    driver.find_element(By.ID,"female").click()

    driver.find_element(By.ID,"course").send_keys("MBA")

    driver.find_element(By.TAG_NAME,"button").click()

    alert = driver.switch_to.alert
    print("Test 1:", alert.text)
    alert.accept()


def test_invalid_name():
    driver.refresh()

    driver.find_element(By.ID,"name").send_keys("Aishi123")

    driver.find_element(By.TAG_NAME,"button").click()

    alert = driver.switch_to.alert
    print("Test 2:", alert.text)
    alert.accept()


def test_invalid_email():
    driver.refresh()

    driver.find_element(By.ID,"name").send_keys("Aishi")

    driver.find_element(By.ID,"email").send_keys("aishi@gmail")

    driver.find_element(By.TAG_NAME,"button").click()

    alert = driver.switch_to.alert
    print("Test 3:", alert.text)
    alert.accept()


def test_password_mismatch():
    driver.refresh()

    driver.find_element(By.ID,"name").send_keys("Aishi")

    driver.find_element(By.ID,"email").send_keys("aishi@gmail.com")

    driver.find_element(By.ID,"password").send_keys("Secure123")

    driver.find_element(By.ID,"confirmPassword").send_keys("Secure321")

    driver.find_element(By.TAG_NAME,"button").click()

    alert = driver.switch_to.alert
    print("Test 4:", alert.text)
    alert.accept()


test_valid_registration()
test_invalid_name()
test_invalid_email()
test_password_mismatch()

driver.quit()